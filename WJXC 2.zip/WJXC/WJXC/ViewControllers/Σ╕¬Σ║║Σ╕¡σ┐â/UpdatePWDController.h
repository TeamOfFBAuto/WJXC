//
//  UpdatePWDController.h
//  WJXC
//
//  Created by lichaowei on 15/7/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//
/**
 *  更新 修改密码
 */
#import "MyViewController.h"

@interface UpdatePWDController : MyViewController

@end
