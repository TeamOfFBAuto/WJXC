//
//  MyCollectController.h
//  WJXC
//
//  Created by lichaowei on 15/7/7.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

@interface MyCollectController : MyViewController

@end
