//
//  AboutUsController.h
//  WJXC
//
//  Created by lichaowei on 15/7/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//
/**
 *  关于我们
 */
#import "MyViewController.h"

@interface AboutUsController : MyViewController

@end
