//
//  GsearchViewController.h
//  WJXC
//
//  Created by gaomeng on 15/7/19.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


//搜索vc

#import "MyViewController.h"

@interface GsearchViewController : MyViewController



@end
