//
//  ClassView.h
//  WJXC
//
//  Created by gaomeng on 15/7/24.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassView : UIView


@property(nonatomic,assign)NSInteger section;
@property(nonatomic,assign)NSInteger row;

@end
