//
//  ConfirmOrderController.h
//  WJXC
//
//  Created by lichaowei on 15/7/18.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

/**
 *  确认订单
 */
#import "MyViewController.h"

@interface ConfirmOrderController : MyViewController

@property(nonatomic,retain)NSArray *productArray;//购买的商品
@property(nonatomic,assign)float sumPrice;

@end
