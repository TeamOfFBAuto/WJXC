//
//  SettingsViewController.h
//  WJXC
//
//  Created by lichaowei on 15/7/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

@interface SettingsViewController : MyViewController

@end
