//
//  ProductDetailViewController.h
//  WJXC
//
//  Created by gaomeng on 15/7/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//


//单品详情

#import "MyViewController.h"

#import "GCycleScrollView.h"

@interface ProductDetailViewController : MyViewController

@end
