//
//  ProductCommentViewController.h
//  WJXC
//
//  Created by gaomeng on 15/7/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//



//商品评论

#import "MyViewController.h"
#import "ProductDetailModel.h"

@interface ProductCommentViewController : MyViewController


@property(nonatomic,strong)ProductDetailModel *model;

@end
