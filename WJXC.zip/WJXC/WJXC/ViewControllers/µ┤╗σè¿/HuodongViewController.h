//
//  HuodongViewController.h
//  WJXC
//
//  Created by gaomeng on 15/8/3.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"

@interface HuodongViewController : MyViewController


@property(nonatomic,strong)NSString *huodongId;

@end
