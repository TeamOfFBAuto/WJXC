//
//  BaseModel.h
//  FBCircle
//
//  Created by lichaowei on 14-8-6.
//  Copyright (c) 2014年 soulnear. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject
-(id)initWithDictionary:(NSDictionary *)dic;
@end
