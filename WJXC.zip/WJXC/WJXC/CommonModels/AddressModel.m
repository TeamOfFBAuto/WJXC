//
//  AddressModel.m
//  WJXC
//
//  Created by lichaowei on 15/7/15.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "AddressModel.h"

@implementation AddressModel

@end
