//
//  adverModel.m
//  WJXC
//
//  Created by gaomeng on 15/7/28.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "adverModel.h"

@implementation adverModel

@end
