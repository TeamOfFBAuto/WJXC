//
//  ProductDetailModel.m
//  WJXC
//
//  Created by gaomeng on 15/7/8.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "ProductDetailModel.h"

@implementation ProductDetailModel

@end
