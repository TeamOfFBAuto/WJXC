//
//  OrderModel.m
//  WJXC
//
//  Created by lichaowei on 15/7/30.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "OrderModel.h"

@implementation OrderModel

-(instancetype)initWithDictionary:(NSDictionary *)dic
{
    self = [super initWithDictionary:dic];
    
    if (self) {
        
        
    }
    return self;
}

@end
