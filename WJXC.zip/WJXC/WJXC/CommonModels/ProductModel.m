//
//  ProductModel.m
//  WJXC
//
//  Created by lichaowei on 15/7/16.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "ProductModel.h"

@implementation ProductModel

@end
